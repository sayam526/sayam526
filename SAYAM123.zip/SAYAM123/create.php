<?php
include "Project.php";

if(isset($_POST['submit'])){

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];

$sql = "INSERT INTO curd(Name,email,Password,Mobile) values ('$name','$email','$password','$mobile')";
$result = $conn->query($sql);

if($result == TRUE){
    echo "New record created succesfully";
}
else {
    echo "Error:" .$sql . "<br>". $conn->error;
}
$conn->close();
}

?>
<!DOCTYPE html>
<html>
    <head>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
    <body>
        <h2> Signup Form</h2>
      
        <form method="POST">
        <div class="mb-3">
    <label class="form-label">name</label>
    <input type="text" class="form-control" name="name" placeholder="enter your name">
   
  </div>
  <div class="mb-3">
    <label class="form-label">email</label>
    <input type="email" class="form-control" name="email" placeholder="enter your email">
   
  </div>
  <div class="mb-3">
    <label class="form-label">password</label>
    <input type="password" class="form-control" name="password" placeholder="enter your password">
   
  </div>
  <div class="mb-3">
    <label class="form-label">phone no</label>
    <input type="text" class="form-control" name="mobile" placeholder="enter your phone number">
   
  </div>
  <button type="submit" class="btn btn-primary" name="submit">Submit</button>
</form>

</body>
</html>
