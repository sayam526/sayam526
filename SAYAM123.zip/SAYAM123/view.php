<?php
include "Project.php";
$sql = "SELECT * FROM curd";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html>
    <title> View page</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
</head>
<body>
    <div class="container">
        <h2>users</h2>
        <table class="table">
         <head>
            <tr>
            <th>ID </th>
            <th>name</th>
            <th>email</th>
            <th>Password</th>
            <th>mobile</th>
</tr>
</thead>
<tbody>
    <?php
    if($result->num_rows>0) {
        while($row = $result->fetch_assoc()) {
    

?>
<tr>
    <td><?php echo $row['Id']; ?> </td>
    <td><?php echo $row['Name']; ?> </td>
    <td><?php echo $row['email']; ?> </td>
    <td><?php echo $row['Password']; ?> </td>
    <td><?php echo $row['Mobile']; ?> </td>
   <td><a class="btn btn-primary"  href="update.php?id=<?php echo $row['Id'];?>">update</a>&nbsp;
   <a class="btn btn-danger"  href="delete.php?id=<?php echo $row['Id'];?>">delete</a>
</tr>
<?php
        }}
        ?>
    </tbody>
</table>
</body>
<html>
        
    
