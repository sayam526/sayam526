<?php
$host ='localhost';
$user = 'root';
$pass = '';
$dbname='sayam123';
$conn = mysqli_connect($host, $user, $pass,$dbname);
if(! $conn )
{
    die('Could not connect:'.mysqli_error());
}
else{
    echo "Connected Succesfully";
}


?>