<?php
include "Project.php";
if(isset($_GET['id'])) {
    $user_id = $_GET['id'];
    $sql = "DELETE FROM curd WHERE Id=$user_id";
   $result=$conn->query($sql);
    if($result==TRUE){
        // echo "Record deleted successfully.";
        header("location:view.php");
    }else
    {
      echo "error".$sql."<br>".$conn->error;
    }
}
?>
