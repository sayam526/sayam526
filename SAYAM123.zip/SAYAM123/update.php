<?php
include 'Project.php';
if(isset($_POST['update'])) {
    $id = $_POST['id'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $Password = $_POST['Password'];
    $mobile= $_POST['mobile'];
$sql = "UPDATE curd SET name='$name',email='$email',Password='$Password', mobile='$mobile' where Id=$id ";
$result = $conn->query($sql);
if($result == TRUE){
    // echo "Record Update Succesfully";
    header("location:view.php");

}
else {
    echo "Error:".$sql."<br>".$conn->error;
}
}
if(isset($_GET['id'])){
    $user_id = $_GET['id'];
    $sql = "SELECT * FROM curd WHERE ID=$user_id";
    $result = $conn->query($sql);
    if($result->num_rows >0) {
        while($row= $result->fetch_assoc()) {
            $id_name = $row['Id'];
            $name_name = $row['Name'];
            $email_name = $row['email'];
            $Password_name = $row['Password'];
            $mobile_name = $row['Mobile'];
            // $id = $row['id'];

            
        }
        ?>
   <html>
        <head>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    </head>
    <body>
        <hr> User update Form</hr>

        <form method="post">
      
            <fieldset>
                <legend>Persnol information:</legend>
                
                <div class="mb-3">
                id name:<br>
                <input type="text"  class="form-control" name="id" value="<?php echo $id_name; ?>">
                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
    </div>
    <div class="mb-3">
                name:<br>
                <input type="text" name="name"   class="form-control" value="<?php echo $name_name; ?>">
                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
                </div>
                <div class="mb-3">
                email:<br>
                <input type="text" name="email"  class="form-control" value="<?php echo $email_name; ?>">
                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
    </div>
    <div class="mb-3">
                Password:<br>
                <input type="text" name="Password"  class="form-control"  value="<?php echo $Password_name; ?>">
                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
    </div>
    <div class="mb-3">
                mobile:<br>
                <input type="text" name="mobile"  class="form-control" value="<?php echo $mobile_name; ?>">
                <input type="hidden" name="user_id" value="<?php echo $id; ?>">
    </div>
                <input type="submit" value="Update" name="update">
    </fieldset>
    </div>
    </form>
    </body>
    </html>
    <?php
    
     }
    } else{
        //If the 'id' value is not valid, redirect the user back to view.php page
        header('Location: view.php');
    }
    

?>



